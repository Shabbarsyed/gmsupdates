let data = [
    { type: 'Comedy', count: 4 },
    { type: 'Action', count: 5 },
    { type: 'Romance', count: 6 },
    { type: 'Drama', count: 1 },
    { type: 'SciFi', count: 4 }
  ];
  
  let angles = [];
  
  function setup() {
    createCanvas(400, 400);
    calculateAngles();
    noLoop();
  }
  
  function draw() {
    background(220);
    let centerX = width / 2;
    let centerY = height / 2;
    let radius = min(width, height) / 2 - 50;
    let startAngle = 0;
  
    for (let i = 0; i < data.length; i++) {
      let type = data[i].type;
      let count = data[i].count;
      let angle = radians(angles[i]);
  
      // Calculate the end angle based on the start angle and the current slice's angle
      let endAngle = startAngle + angle;
  
      // Set a random color for each slice
      let fillColor = color(random(255), random(255), random(255));
  
      // Draw the slice
      fill(fillColor);
      arc(centerX, centerY, radius, radius, startAngle, endAngle);
  
      // Calculate the label position
      let labelAngle = startAngle + angle / 2;
      let labelX = centerX + (radius / 2) * cos(labelAngle);
      let labelY = centerY + (radius / 2) * sin(labelAngle);
  
      // Draw the label
      fill(0);
      textAlign(CENTER, CENTER);
      text(type, labelX, labelY);
  
      // Update the start angle for the next slice
      startAngle = endAngle;
    }
  }
  
  function calculateAngles() {
    let totalCount = 0;
    for (let i = 0; i < data.length; i++) {
      let count = data[i].count;
      totalCount += count;
      angles.push(count);
    }
  
    // Convert the counts to percentages
    for (let i = 0; i < angles.length; i++) {
      angles[i] = (angles[i] / totalCount) * 360;
    }
  }
  