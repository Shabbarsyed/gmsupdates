let angle = 0;
let symbolSize = 200;
let symbolPosition;

function setup() {
  createCanvas(400, 400);
  symbolPosition = createVector(width / 2, height / 2);
}

function draw() {
  background(220);

  // Update the symbol position based on mouse position
  symbolPosition = createVector(mouseX, mouseY);

  // Draw the spinning Yin-Yang symbol
  drawYinYang(symbolPosition, symbolSize, angle);

  // Update the angle for the next frame
  angle += 0.05;
}

function drawYinYang(position, size, rotation) {
  let radius = size / 2;

  // Draw the big black and white halves
  push();
  translate(position.x, position.y);
  rotate(rotation);
  noStroke();
  fill(0);
  arc(0, 0, size, size, -PI / 2, PI / 2);
  fill(255);
  arc(0, 0, size, size, PI / 2, 3 * PI / 2);
  pop();

  // Draw the medium circles
  let mediumSize = size * 0.3;
  let mediumOffset = size * 0.15;
  let mediumPosition = p5.Vector.add(position, createVector(mediumOffset, 0).rotate(rotation));

  fill(0);
  circle(mediumPosition.x, mediumPosition.y, mediumSize);
  fill(255);
  circle(mediumPosition.x, mediumPosition.y, mediumSize / 2);

  // Draw the small circles
  let smallSize = size * 0.1;
  let smallOffset = size * 0.35;
  let smallPosition = p5.Vector.add(position, createVector(smallOffset, 0).rotate(rotation));

  fill(255);
  circle(smallPosition.x, smallPosition.y, smallSize);
  fill(0);
  circle(smallPosition.x, smallPosition.y, smallSize / 2);
}
