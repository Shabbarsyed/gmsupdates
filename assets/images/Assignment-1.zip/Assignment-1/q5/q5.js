function setup() {
    createCanvas(600, 600); // Adjust the canvas size as needed
    background(255); // Set background color to white
    noLoop(); // Run draw() function only once
  }
  
  function draw() {
    // Call functions to draw each part of the six-part drawing
    drawPart1();
    drawPart2();
    drawPart3();
    drawPart4();
    drawPart5();
    drawPart6();
  }
  
  // Function to draw the first part
  function drawPart1() {
    let partWidth = width / 3;
    let partHeight = height / 2;
  
    fill(255, 0, 0); // Set fill color to red
    rect(0, 0, partWidth, partHeight); // Draw the red background
  
    fill(0, 0, 255); // Set fill color to blue
    for (let y = 0; y < partHeight; y += 20) {
      line(0, y, partWidth, y); // Draw horizontal parallel lines
    }
  
    fill(255, 255, 0); // Set fill color to yellow
    let circleSize = min(partWidth, partHeight) * 0.5; // Calculate circle size
    let circleX = partWidth / 2; // Calculate circle center x-coordinate
    let circleY = partHeight / 2; // Calculate circle center y-coordinate
    ellipse(circleX, circleY, circleSize); // Draw the yellow circle
  
    fill(255, 0, 0); // Set fill color to red
    for (let x = circleX - circleSize / 2; x <= circleX + circleSize / 2; x += 20) {
      line(x, 0, x, partHeight); // Draw vertical parallel lines within the circle
    }
  }
  
  // Implement drawPart2() to draw the second part in a similar way as drawPart1()
  function drawPart2() {
    let partWidth = width / 3;
    let partHeight = height / 2;
  
    fill(255, 0, 0); // Set fill color to red
    rect(0, 0, partWidth, partHeight); // Draw the red background
  
    fill(0, 0, 255); // Set fill color to blue
    for (let y = 0; y < partHeight; y += 20) {
      line(0, y, partWidth, y); // Draw horizontal parallel lines
    }
  
    fill(255, 255, 0); // Set fill color to yellow
    let circleSize = min(partWidth, partHeight) * 0.5; // Calculate circle size
    let circleX = partWidth / 2; // Calculate circle center x-coordinate
    let circleY = partHeight / 2; // Calculate circle center y-coordinate
    ellipse(circleX, circleY, circleSize); // Draw the yellow circle
  
    fill(255, 0, 0); // Set fill color to red
    for (let x = circleX - circleSize / 2; x <= circleX + circleSize / 2; x += 20) {
      line(x, 0, x, partHeight); // Draw vertical parallel lines within the circle
    }
  }
  // Implement drawPart3() to draw the third part in a similar way as drawPart1()
  function drawPart3() {
    let partWidth = width / 3;
    let partHeight = height / 2;
  
    fill(255, 0, 0); // Set fill color to red
    rect(0, 0, partWidth, partHeight); // Draw the red background
  
    fill(0, 0, 255); // Set fill color to blue
    for (let y = 0; y < partHeight; y += 20) {
      line(0, y, partWidth, y); // Draw horizontal parallel lines
    }
  
    fill(255, 255, 0); // Set fill color to yellow
    let circleSize = min(partWidth, partHeight) * 0.5; // Calculate circle size
    let circleX = partWidth / 2; // Calculate circle center x-coordinate
    let circleY = partHeight / 2; // Calculate circle center y-coordinate
    ellipse(circleX, circleY, circleSize); // Draw the yellow circle
  
    fill(255, 0, 0); // Set fill color to red
    for (let x = circleX - circleSize / 2; x <= circleX + circleSize / 2; x += 20) {
      line(x, 0, x, partHeight); // Draw vertical parallel lines within the circle
    }
  }
  // Implement drawPart4() to draw the fourth part in a similar way as drawPart1()
  function drawPart4() {
    let partWidth = width / 3;
    let partHeight = height / 2;
  
    fill(255, 0, 0); // Set fill color to red
    rect(0, 0, partWidth, partHeight); // Draw the red background
  
    fill(0, 0, 255); // Set fill color to blue
    for (let y = 0; y < partHeight; y += 20) {
      line(0, y, partWidth, y); // Draw horizontal parallel lines
    }
  
    fill(255, 255, 0); // Set fill color to yellow
    let circleSize = min(partWidth, partHeight) * 0.5; // Calculate circle size
    let circleX = partWidth / 2; // Calculate circle center x-coordinate
    let circleY = partHeight / 2; // Calculate circle center y-coordinate
    ellipse(circleX, circleY, circleSize); // Draw the yellow circle
  
    fill(255, 0, 0); // Set fill color to red
    for (let x = circleX - circleSize / 2; x <= circleX + circleSize / 2; x += 20) {
      line(x, 0, x, partHeight); // Draw vertical parallel lines within the circle
    }
  }
  // Implement drawPart5() to draw the fifth part in a similar way as drawPart1()
  function drawPart5() {
    let partWidth = width / 3;
    let partHeight = height / 2;
  
    fill(255, 0, 0); // Set fill color to red
    rect(0, 0, partWidth, partHeight); // Draw the red background
  
    fill(0, 0, 255); // Set fill color to blue
    for (let y = 0; y < partHeight; y += 20) {
      line(0, y, partWidth, y); // Draw horizontal parallel lines
    }
  
    fill(255, 255, 0); // Set fill color to yellow
    let circleSize = min(partWidth, partHeight) * 0.5; // Calculate circle size
    let circleX = partWidth / 2; // Calculate circle center x-coordinate
    let circleY = partHeight / 2; // Calculate circle center y-coordinate
    ellipse(circleX, circleY, circleSize); // Draw the yellow circle
  
    fill(255, 0, 0); // Set fill color to red
    for (let x = circleX - circleSize / 2; x <= circleX + circleSize / 2; x += 20) {
      line(x, 0, x, partHeight); // Draw vertical parallel lines within the circle
    }
  }
  // Implement drawPart6() to draw the sixth part in a similar way as drawPart1()
  function drawPart6() {
    let partWidth = width / 3;
    let partHeight = height / 2;
  
    fill(255, 0, 0); // Set fill color to red
    rect(0, 0, partWidth, partHeight); // Draw the red background
  
    fill(0, 0, 255); // Set fill color to blue
    for (let y = 0; y < partHeight; y += 20) {
      line(0, y, partWidth, y); // Draw horizontal parallel lines
    }
  
    fill(255, 255, 0); // Set fill color to yellow
    let circleSize = min(partWidth, partHeight) * 0.5; // Calculate circle size
    let circleX = partWidth / 2; // Calculate circle center x-coordinate
    let circleY = partHeight / 2; // Calculate circle center y-coordinate
    ellipse(circleX, circleY, circleSize); // Draw the yellow circle
  
    fill(255, 0, 0); // Set fill color to red
    for (let x = circleX - circleSize / 2; x <= circleX + circleSize / 2; x += 20) {
      line(x, 0, x, partHeight); // Draw vertical parallel lines within the circle
    }
  }
  function drawWallWithColorBands() {
    let numBands = 10; // Adjust the number of bands as needed
    let bandHeight = height / numBands;
    
    for (let i = 0; i < numBands; i++) {
      let r = random(255); // Generate a random value for red
      let g = random(255); // Generate a random value for green
      let b = random(255); // Generate a random value for blue
      fill(r, g, b); // Set fill color to random values
      
      let y = i * bandHeight; // Calculate y-coordinate for each band
      
      beginShape();
      curveVertex(0, y); // Start the curve at the left edge of the canvas
      for (let x = 0; x <= width; x += 10) {
        let offset = random(-10, 10); // Add randomness to the curve
        curveVertex(x, y + offset); // Draw the curve
      }
      curveVertex(width, y); // End the curve at the right edge of the canvas
      endShape();
    }
  }
  
  // Call the drawWallWithColorBands() function to draw the irregular wavy color bands
  drawWallWithColorBands();
  