function setup() {
    createCanvas(400, 300);
    background("green");
  }
  
  let angle1 = 0;
  let angle2 = 0;
  
  function draw() {
    background("green");
  
    // Draw the gray road ellipse
    strokeWeight(40);
    stroke("gray");
    fill("gray");
    ellipse(width / 2, height / 2, 200, 100);
  
    // Draw the yellow center lines
    strokeWeight(1);
    stroke("yellow");
    line(width / 2 - 50, height / 2, width / 2 + 50, height / 2);
    line(width / 2 - 50, height / 2 + 5, width / 2 + 50, height / 2 + 5);
  
    // Calculate the positions of the circles
    let circle1X = width / 2 + cos(angle1) * 90;
    let circle1Y = height / 2 + sin(angle1) * 90;
    let circle2X = width / 2 + cos(angle2) * 90;
    let circle2Y = height / 2 + sin(angle2) * 90;
  
    // Draw the circles
    fill("white");
    circle(circle1X, circle1Y, 10);
    circle(circle2X, circle2Y, 10);
  
    // Update the angles for the next frame
    angle1 += 1;
    angle2 += 2;
  }
  