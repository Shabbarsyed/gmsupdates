let angle = 0;

function setup() {
  createCanvas(600, 200);
}

function draw() {
  background(220);

  // Call custom functions to draw different elements
  drawBackground();
  drawText();
  drawAnimation();
}

// Custom function to draw the background
function drawBackground() {
  fill(100, 150, 200); // Set background color
  rect(0, 0, width, height);

  // Draw looped shapes in the background
  noStroke();
  fill(255, 200, 0); // Set shape color
  for (let x = -100; x <= width + 100; x += 100) {
    for (let y = -100; y <= height + 100; y += 100) {
      push();
      translate(x, y);
      rotate(angle);
      rect(0, 0, 80, 80);
      pop();
    }
  }
}

// Custom function to draw the text
function drawText() {
  textSize(32);
  textAlign(CENTER, CENTER);
  fill(255);
  text("Join our p5.js course!", width / 2, height / 2);
}

// Custom function to draw the animation
function drawAnimation() {
  let animationSize = 100;
  let animationX = map(sin(angle), -1, 1, animationSize, width - animationSize);
  let animationY = height / 2;

  fill(255, 0, 0); // Set animation color
  ellipse(animationX, animationY, animationSize, animationSize);

  angle += 0.05; // Update angle for animation
}
