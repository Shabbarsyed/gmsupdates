let time = 0; // Initialize time variable

function setup() {
  createCanvas(600, 600); // Adjust the canvas size as needed
}

function draw() {
  background(255); // Set background color to white

  drawGrid();
  drawLissajousCurve();

  time++; // Increment time variable for animation
}

function drawGrid() {
  let gridSize = 20; // Adjust the grid size as needed
  let numLines = width / gridSize; // Calculate the number of lines

  stroke(0, 100); // Set stroke color to black with transparency

  // Draw vertical lines
  for (let i = 1; i < numLines; i++) {
    let x = i * gridSize;
    line(x, 0, x, height);
  }

  // Draw horizontal lines
  for (let i = 1; i < numLines; i++) {
    let y = i * gridSize;
    line(0, y, width, y);
  }
}

function drawLissajousCurve() {
  let centerX = width / 2; // Calculate the center x-coordinate
  let centerY = height / 2; // Calculate the center y-coordinate
  let radius = min(width, height) * 0.4; // Calculate the radius of the curve

  let numPoints = 100; // Adjust the number of points on the curve as needed

  stroke(0); // Set stroke color to black
  noFill();

  beginShape();
  for (let i = 0; i < numPoints; i++) {
    let angleX = map(i, 0, numPoints, 0, TWO_PI); // Calculate the x-angle based on the current point
    let angleY = map(i, 0, numPoints, 0, TWO_PI); // Calculate the y-angle based on the current point

    let x = centerX + radius * sin(angleX + time * 0.02); // Calculate x-coordinate using sine function
    let y = centerY + radius * cos(angleY + time * 0.03); // Calculate y-coordinate using cosine function

    vertex(x, y); // Add vertex to the shape
  }
  endShape(CLOSE);
}

// Call the draw() function to continuously update and animate the grid and Lissajous curve
draw();
